<?php

$dbname = 'sensor_db';
$dbuser = 'root';  
$dbpass = ''; 
$dbhost = 'localhost'; 

$connect = @mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

if(!$connect){
	echo "Error: " . mysqli_connect_error();
	exit();
}

echo "Connection Success!<br><br>";
$query = "SELECT * FROM dht11";
$result = mysqli_query($connect,$query);
while($data = mysqli_fetch_assoc($result))
{
	$a = "id:";
	$b = "temperature:";
	$c = "humidity:";
	$d = "date&time:";
	$e = " ";
	echo $a." ".$data['id']." ".$b." ".$data['temperature']." ".$c." ".$data['humidity']." ".$d." ".$data['datetime'];
	echo "<br>";
}

?>